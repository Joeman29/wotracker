require 'spec_helper'

describe 'workout edit page' do
   it 'displays proper workout data', js:true do

   end
end